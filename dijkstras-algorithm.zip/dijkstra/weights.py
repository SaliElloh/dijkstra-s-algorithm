import random

a = open("./G1.txt")
line = a.readline()
while line:
    r = random.randint(1, 101)
    print(" ".join(line[:-1].split(" ")[:-1] + [str(r)]))

    line = a.readline()
