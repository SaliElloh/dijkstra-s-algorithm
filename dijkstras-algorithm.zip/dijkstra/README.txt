Easy command to compile then run:
make; ./a.out