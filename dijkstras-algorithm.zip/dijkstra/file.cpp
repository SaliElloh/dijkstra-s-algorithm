#include <limits>
#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

int main(){
    vector<vector<int> > list(10, vector<int>(10, 1));

    for (int i = 0; i < list.size(); i++)
    {
        for (int j = 0; j < list.size(); j++)
        {
            cout << list[i][j] << " ";
        }
        
    }
    

    // cout << list.size() << endl;

    cout << "Hello World!" << endl;
}