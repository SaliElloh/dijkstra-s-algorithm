#include <limits>
#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

#define DATA_FILENAME "./G1.txt"

struct result {
	vector<int> parent;
	vector<int> distance;
};

// this function takes a list of distances
// it looks at the unvisited nodes only and returns the one with minimum distance
int minimumDistance(vector<int> distance, vector<bool> visited, int size)
{
	int min = INT_MAX;		 // 1
	int min_index = INT_MAX; // 1

	// V iterations
	for (int i = 0; i < size; i++)
	{
		if (!visited[i] && distance[i] <= min) // 5
		{
			min = distance[i]; // 2
			min_index = i;	   // 1
		}
		// total: 8
	}

	return min_index; // 1

	// TOTAL COST: 8 times V + 3
}

// this function
void printParentPath(vector<int> parent, vector<int> distance, int i)
{
	if (parent[i] == -1)
	{
		return;
	}
	printParentPath(parent, distance, parent[i]);
	cout << i + 1 << ": " << distance[i] << endl;
}

result dijkstra(vector<vector<int> > graph, int source)
{
	int numVertices = graph.size();

	// used for displaying the results
	vector<int> parent(numVertices, 0);
	parent[0] = -1;

	// list of distances from source using distance[vertexIndex]
	vector<int> distance(numVertices, INT_MAX);

	// array that tells us whether vertex is visited using visited[vertexIndex]
	vector<bool> visited(numVertices, false);

	// distance from source to source is 0
	distance[source] = 0;

	// OUTER LOOP RUNS V-1 ITERATIONS
	// this loop will run numVertices - 1 times (V - 1)
	for (int i = 0; i < numVertices - 1; i++)
	{
		// get the adjacent vertex with minimum cost
		// FIRST SUBSECTION total: 8 times V + 3
		int adjNodeWithMinCostIdx = minimumDistance(distance, visited, numVertices);

		// mark that one as visited
		visited[adjNodeWithMinCostIdx] = true; // 1

		// loop over the rest (numVertices)
		// SECOND SUBSECTION
		for (int j = 0; j < numVertices; j++)
		{
			int curr_distance = distance[adjNodeWithMinCostIdx] + graph[adjNodeWithMinCostIdx][j]; // 5
			if (!visited[j] && graph[adjNodeWithMinCostIdx][j] && curr_distance < distance[j])	   // 6
			{
				// backtrack
				parent[j] = adjNodeWithMinCostIdx; // 2

				// set the new best distance
				distance[j] = curr_distance; // 2
			}

			// total loop cost: 15 times V
		}

		// total: (V - 1) times (8 times V + 3 + 1 + 15 times V)
		// -> O(V^2)
	}

	// this code is used for display (ignoring)

	result r;
	r.parent = parent;
	r.distance = distance;
	return r;
}

void printLeastCostPath(vector<vector<int> > graph, int source, int destination) {
		result r = dijkstra(graph, source);

		cout << "Source Node: " << source + 1 << endl;
		cout << "Destination Node: " << destination + 1 << endl;
		cout << "Distance: " << r.distance[destination] << endl;
		cout << "Path: " << endl << source + 1 << ": " << 0 << endl;
		printParentPath(r.parent, r.distance, destination);
		cout << endl;
}

int main()
{
	ifstream infile;
	infile.open("./G1 weighted.txt");

	int numVertices;
	infile >> numVertices;
	int numEdges;
	infile >> numEdges;

	// define graph variable of size numVertices
	vector<vector<int>> graph(numVertices, vector<int>(numVertices, 0));

	// parse the rest of the data
	int fromV, toV, weight;
	while (infile >> fromV >> toV >> weight)
	{
		graph[fromV - 1][toV - 1] = weight;
	}

	// set the desired source and destination
	int source;
	int destination;

	cout << "Enter source: ";
	cin >> source;
	cout << "Enter destination: ";
	cin >> destination;

	// execute function that gets least cost path from source to destination;
	printLeastCostPath(graph, source-1, destination-1);
}